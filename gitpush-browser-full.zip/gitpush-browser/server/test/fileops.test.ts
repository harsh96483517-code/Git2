import test from 'node:test';
import assert from 'node:assert/strict';
import { deletePath, makeFolder, previewFile, renamePath } from '../src/fileops.js';

const f = (path: string, data: string | Buffer = 'x') => ({ path, data: Buffer.from(data) });
const paths = (fs: { path: string }[]) => fs.map((x) => x.path).sort();

test('rename moves a file and a whole folder', () => {
  assert.deepEqual(paths(renamePath([f('a.txt')], 'a.txt', 'docs/a.txt')), ['docs/a.txt']);
  assert.deepEqual(paths(renamePath([f('src/a.js'), f('src/b/c.js')], 'src', 'lib')), ['lib/a.js', 'lib/b/c.js']);
});

test('rename refuses collisions, clashes, self-moves and unsafe paths', () => {
  assert.throws(() => renamePath([f('a'), f('b')], 'a', 'b'), /already exists/);
  assert.throws(() => renamePath([f('a'), f('b/c')], 'b/c', 'a/c'), /cannot share/);
  assert.throws(() => renamePath([f('src/a')], 'src', 'src/inner'), /itself/);
  assert.throws(() => renamePath([f('a')], 'a', '.git/x'), /not allowed/);
  assert.throws(() => renamePath([f('a')], 'a', '../x'), /not allowed/);
  assert.throws(() => renamePath([f('a')], 'missing', 'b'), /Nothing found/);
});

test('delete removes a folder but never the last file', () => {
  assert.deepEqual(paths(deletePath([f('a/1'), f('a/2'), f('b')], 'a')), ['b']);
  assert.throws(() => deletePath([f('a')], 'a'), /at least one file/);
  assert.throws(() => deletePath([f('a'), f('b')], 'zzz'), /Nothing found/);
});

test('new folder adds .gitkeep and refuses existing names', () => {
  assert.deepEqual(paths(makeFolder([f('a')], 'docs')), ['a', 'docs/.gitkeep']);
  assert.throws(() => makeFolder([f('docs/x')], 'docs'), /already exists/);
  assert.throws(() => makeFolder([f('docs')], 'docs'), /already exists/);
});

test('preview distinguishes text, binary and images', () => {
  assert.equal(previewFile([f('a.txt', 'hello')], 'a.txt').kind, 'text');
  assert.equal(previewFile([f('a.bin', Buffer.from([1, 0, 2]))], 'a.bin').kind, 'none');
  assert.equal(previewFile([f('a.png', Buffer.from([137, 80]))], 'a.png').kind, 'image');
  assert.throws(() => previewFile([f('a')], 'nope'), /not found/);
});
