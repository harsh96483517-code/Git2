import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { getJob, publicJob, runningJob, startJob, type Job, type PushRequest } from '../src/jobs.js';
import { fakeGitHub, gitSha } from './fakegithub.js';

const realFetch = globalThis.fetch;
after(() => { globalThis.fetch = realFetch; });

const files = [{ path: 'a.txt', data: Buffer.from('A') }, { path: 'dir/b.txt', data: Buffer.from('B') }];
const req = (over: Partial<PushRequest> = {}): PushRequest => ({ token: 'secret-token', repo: 'o/r', branch: 'main', folder: '', message: 'm', onConflict: 'abort', files, ...over });
const settle = async (job: Job) => { for (let i = 0; i < 400 && job.status === 'running'; i++) await new Promise((r) => setTimeout(r, 5)); return job; };
const blobCalls = (calls: { path: string }[]) => calls.filter((c) => c.path.endsWith('/git/blobs')).length;

test('a successful job reports progress, commit link and counts', async () => {
  fakeGitHub();
  const job = startJob('s1', req());
  await settle(job);
  assert.equal(job.status, 'done');
  assert.ok(job.commitUrl?.endsWith('/commit/c1'));
  assert.equal(job.uploaded, 2);
  assert.equal(job.done, 2);
  assert.equal(job.total, 2);
});

test('conflicts surface as a conflict status with the paths', async () => {
  fakeGitHub({ existing: { 'a.txt': 'deadbeef' } });
  const job = await settle(startJob('s1', req()));
  assert.equal(job.status, 'conflict');
  assert.deepEqual(job.conflicts, ['a.txt']);
});

test('cancelling before the upload starts ends as cancelled', async () => {
  fakeGitHub();
  const job = startJob('s1', req());
  job.ctl.abort();
  await settle(job);
  assert.equal(job.status, 'cancelled');
});

test('a failed file fails the job without a commit', async () => {
  fakeGitHub({ failContent: 'A' });
  const job = await settle(startJob('s1', req()));
  assert.equal(job.status, 'failed');
  assert.deepEqual(job.failed, ['a.txt']);
  assert.match(job.error ?? '', /Nothing was committed/);
});

test('GitHub errors become readable messages', async () => {
  for (const [status, pattern] of [[401, /sign-in/], [403, /refused/], [404, /not found/], [422, /Nothing was changed/]] as const) {
    fakeGitHub({ refStatus: status });
    const job = await settle(startJob('s1', req()));
    assert.equal(job.status, 'failed');
    assert.match(job.error ?? '', pattern, String(status));
  }
});

test('jobs are private to their session and never expose secrets', async () => {
  fakeGitHub();
  const job = startJob('owner', req());
  assert.equal(runningJob('owner')?.id, job.id);
  assert.equal(runningJob('someone-else'), undefined);
  await settle(job);
  assert.equal(runningJob('owner'), undefined);
  assert.ok(getJob('owner', job.id));
  assert.equal(getJob('someone-else', job.id), undefined);
  const pub = publicJob(job);
  for (const k of ['ctl', 'cache', 'sid', 'exp', 'token']) assert.ok(!(k in pub), k);
  assert.ok(!JSON.stringify(pub).includes('secret-token'));
});

test('retrying a failed job reuses blobs already uploaded', async () => {
  fakeGitHub({ failContent: 'B' });
  const first = await settle(startJob('s1', req()));
  assert.equal(first.status, 'failed');
  const calls = fakeGitHub();
  const second = await settle(startJob('s1', req(), first.id));
  assert.equal(second.status, 'done');
  assert.equal(blobCalls(calls), 1);
});

test('identical files already in the repo are not re-uploaded', async () => {
  const calls = fakeGitHub({ existing: { 'a.txt': gitSha('A') } });
  const job = await settle(startJob('s1', req()));
  assert.equal(job.status, 'done');
  assert.equal(job.unchanged, 1);
  assert.equal(blobCalls(calls), 1);
});
