import test from 'node:test';
import assert from 'node:assert/strict';
import { deleteAllFor, deleteExtraction, getExtraction, saveExtraction } from '../src/extractions.js';

const files = (n = 1) => Array.from({ length: n }, (_, i) => ({ path: `f${i}.txt`, data: Buffer.from('hello') }));

test('an extraction is only visible to the session that made it', () => {
  const e = saveExtraction('s1', 'a.zip', files());
  assert.equal(getExtraction('s1', e.id)?.name, 'a.zip');
  assert.equal(getExtraction('s2', e.id), undefined);
  assert.equal(getExtraction('s1', 'nope'), undefined);
  deleteExtraction('s2', e.id);
  assert.ok(getExtraction('s1', e.id), 'another session cannot delete it');
  deleteExtraction('s1', e.id);
  assert.equal(getExtraction('s1', e.id), undefined);
});

test('each session keeps at most three, evicting the oldest', () => {
  const ids = [1, 2, 3, 4].map((i) => saveExtraction('cap', `z${i}.zip`, files()).id);
  assert.equal(getExtraction('cap', ids[0]), undefined);
  for (const id of ids.slice(1)) assert.ok(getExtraction('cap', id));
  deleteAllFor('cap');
  for (const id of ids) assert.equal(getExtraction('cap', id), undefined);
});

test('byte totals are tracked', () => {
  const e = saveExtraction('bytes', 'b.zip', files(3));
  assert.equal(e.bytes, 15);
  deleteAllFor('bytes');
});
