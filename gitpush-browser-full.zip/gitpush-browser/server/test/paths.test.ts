import test from 'node:test';
import assert from 'node:assert/strict';
import { safePath } from '../src/paths.js';
import { validBranch, validRepo } from '../src/github.js';

test('safePath normalises ordinary paths', () => {
  assert.equal(safePath('a/b/c.txt'), 'a/b/c.txt');
  assert.equal(safePath('./a//b/./c.txt'), 'a/b/c.txt');
  assert.equal(safePath('a\\b\\c.txt'), 'a/b/c.txt');
});

test('safePath rejects traversal, absolute and drive-letter paths', () => {
  for (const bad of ['../x', 'a/../../x', 'a/..', '/etc/passwd', 'C:\\Windows\\x', 'c:/x', '..\\x', 'a\0b']) {
    assert.throws(() => safePath(bad), /ZIP/, bad);
  }
});

test('validBranch accepts normal names and rejects unsafe ones', () => {
  for (const ok of ['main', 'feature/new-files', 'release-1.2']) assert.equal(validBranch(ok), true, ok);
  for (const bad of ['', '/x', 'x/', 'a..b', 'a//b', '.hidden', 'a/.b', 'x.lock', '-x', 'a b', 'a@{b', 'a\\b', 'x.', 5, null]) assert.equal(validBranch(bad), false, String(bad));
});

test('validRepo rejects separators and dot-only names', () => {
  assert.equal(validRepo('octo-cat', 'my.repo_1'), true);
  for (const [o, r] of [['a/b', 'c'], ['a', 'b/c'], ['..', 'x'], ['a', '..'], ['a', '.'], ['', 'x'], ['a', 'b c']]) assert.equal(validRepo(o, r), false, `${o}/${r}`);
});
