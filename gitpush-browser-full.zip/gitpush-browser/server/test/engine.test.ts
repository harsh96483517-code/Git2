import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { commitFiles, ConflictError, type CommitOptions } from '../src/github.js';

const realFetch = globalThis.fetch;
after(() => { globalThis.fetch = realFetch; });

const gitSha = (s: string) => crypto.createHash('sha1').update(`blob ${Buffer.byteLength(s)}\0${s}`).digest('hex');
const f = (path: string, data: string) => ({ path, data: Buffer.from(data) });

interface Call { method: string; path: string; body?: any }
/** Minimal in-memory stand-in for the GitHub Git Data API. */
function fakeGitHub(opts: { existing?: Record<string, string>; failContent?: string } = {}) {
  const calls: Call[] = [];
  let n = 0;
  globalThis.fetch = (async (url: string, init: RequestInit = {}) => {
    const path = String(url).replace('https://api.github.com', '');
    const method = init.method ?? 'GET';
    const body = init.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ method, path, body });
    const json = (d: unknown, status = 200) => new Response(JSON.stringify(d), { status, headers: { 'content-type': 'application/json' } });
    if (method === 'GET' && path.endsWith('/git/ref/heads/main')) return json({ object: { sha: 'c0' } });
    if (method === 'GET' && path.endsWith('/git/commits/c0')) return json({ tree: { sha: 't0' } });
    if (method === 'GET' && path.startsWith('/repos/o/r/git/trees/t0')) return json({ truncated: false, tree: Object.entries(opts.existing ?? {}).map(([p, sha]) => ({ path: p, sha, type: 'blob' })) });
    if (method === 'POST' && path.endsWith('/git/blobs')) {
      if (opts.failContent !== undefined && Buffer.from(body.content, 'base64').toString() === opts.failContent) return json({ message: 'boom' }, 500);
      return json({ sha: `b${++n}` });
    }
    if (method === 'POST' && path.endsWith('/git/trees')) return json({ sha: 't1' });
    if (method === 'POST' && path.endsWith('/git/commits')) return json({ sha: 'c1' });
    if (method === 'PATCH' && path.endsWith('/git/refs/heads/main')) return json({});
    return json({ message: `unexpected ${method} ${path}` }, 404);
  }) as typeof fetch;
  return calls;
}
const base = (over: Partial<CommitOptions> = {}): CommitOptions => ({
  token: 't', owner: 'o', repo: 'r', branch: 'main', destDir: '', message: 'm', onConflict: 'abort',
  files: [f('a.txt', 'A'), f('dir/b.txt', 'B')], ...over
});
const writes = (calls: Call[]) => calls.filter((c) => c.method !== 'GET');
const blobs = (calls: Call[]) => calls.filter((c) => c.path.endsWith('/git/blobs')).length;

test('fresh push makes one commit and a non-forced fast-forward', async () => {
  const calls = fakeGitHub();
  const r = await commitFiles(base());
  assert.ok(r.ok);
  if (!r.ok) return;
  assert.equal(r.uploaded, 2);
  assert.ok(r.url.endsWith('/commit/c1'));
  const tree = calls.find((c) => c.path.endsWith('/git/trees') && c.method === 'POST')!.body;
  assert.equal(tree.base_tree, 't0');
  assert.deepEqual(tree.tree.map((e: any) => e.path).sort(), ['a.txt', 'dir/b.txt']);
  const commit = calls.find((c) => c.path.endsWith('/git/commits') && c.method === 'POST')!.body;
  assert.deepEqual(commit.parents, ['c0']);
  assert.equal(commit.message, 'm');
  const ref = calls.find((c) => c.method === 'PATCH')!.body;
  assert.deepEqual(ref, { sha: 'c1', force: false });
});

test('destination folder is applied and cannot escape upwards', async () => {
  const calls = fakeGitHub();
  await commitFiles(base({ destDir: 'up/x' }));
  let tree = calls.find((c) => c.path.endsWith('/git/trees') && c.method === 'POST')!.body;
  assert.deepEqual(tree.tree.map((e: any) => e.path).sort(), ['up/x/a.txt', 'up/x/dir/b.txt']);
  const calls2 = fakeGitHub();
  await commitFiles(base({ destDir: '../../evil' }));
  tree = calls2.find((c) => c.path.endsWith('/git/trees') && c.method === 'POST')!.body;
  assert.ok(tree.tree.every((e: any) => !e.path.includes('..')));
});

test('conflict in abort mode throws before any write', async () => {
  const calls = fakeGitHub({ existing: { 'a.txt': 'deadbeef' } });
  await assert.rejects(commitFiles(base()), (e: unknown) => e instanceof ConflictError && e.paths.join() === 'a.txt');
  assert.equal(writes(calls).length, 0);
});

test('identical existing content is not a conflict', async () => {
  fakeGitHub({ existing: { 'a.txt': gitSha('A') } });
  const r = await commitFiles(base());
  assert.ok(r.ok && r.uploaded === 1 && r.unchanged === 1);
});

test('skip mode skips clashes; overwrite mode replaces them', async () => {
  fakeGitHub({ existing: { 'a.txt': 'deadbeef' } });
  const s = await commitFiles(base({ onConflict: 'skip' }));
  assert.ok(s.ok && s.uploaded === 1 && s.skipped.join() === 'a.txt');
  fakeGitHub({ existing: { 'a.txt': 'deadbeef' } });
  const o = await commitFiles(base({ onConflict: 'overwrite' }));
  assert.ok(o.ok && o.uploaded === 2);
});

test('a failed blob means no commit and no ref update', async () => {
  const calls = fakeGitHub({ failContent: 'A' });
  const r = await commitFiles(base());
  assert.ok(!r.ok);
  if (r.ok) return;
  assert.deepEqual(r.failed, ['a.txt']);
  assert.ok(!calls.some((c) => c.path.endsWith('/git/trees') || c.path.endsWith('/git/commits') || c.method === 'PATCH'));
});

test('retry reuses blobs that already uploaded', async () => {
  const cache = new Map<string, string>();
  fakeGitHub({ failContent: 'B' });
  const first = await commitFiles(base({ cache }));
  assert.ok(!first.ok);
  const calls = fakeGitHub();
  const second = await commitFiles(base({ cache }));
  assert.ok(second.ok);
  assert.equal(blobs(calls), 1);
});

test('nothing to upload, cancellation and bad repo names are rejected', async () => {
  fakeGitHub({ existing: { 'a.txt': gitSha('A'), 'dir/b.txt': gitSha('B') } });
  await assert.rejects(commitFiles(base()), /Nothing new/);
  const calls = fakeGitHub();
  const ctl = new AbortController();
  ctl.abort();
  await assert.rejects(commitFiles(base({ signal: ctl.signal })), /cancelled/);
  assert.equal(writes(calls).length, 0);
  await assert.rejects(commitFiles(base({ owner: '..' })), /Invalid repository/);
});
