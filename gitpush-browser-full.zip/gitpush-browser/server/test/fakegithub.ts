import crypto from 'node:crypto';

export interface Call { method: string; path: string; body?: any }
export const gitSha = (s: string) => crypto.createHash('sha1').update(`blob ${Buffer.byteLength(s)}\0${s}`).digest('hex');

/** Minimal in-memory stand-in for the GitHub Git Data API (repo o/r, branch main). */
export function fakeGitHub(opts: { existing?: Record<string, string>; failContent?: string; refStatus?: number } = {}) {
  const calls: Call[] = [];
  let n = 0;
  globalThis.fetch = (async (url: string, init: RequestInit = {}) => {
    const path = String(url).replace('https://api.github.com', '');
    const method = init.method ?? 'GET';
    const body = init.body ? JSON.parse(String(init.body)) : undefined;
    calls.push({ method, path, body });
    const json = (d: unknown, status = 200) => new Response(JSON.stringify(d), { status, headers: { 'content-type': 'application/json' } });
    if (method === 'GET' && path.endsWith('/git/ref/heads/main')) return opts.refStatus ? json({ message: 'no' }, opts.refStatus) : json({ object: { sha: 'c0' } });
    if (method === 'GET' && path.endsWith('/git/commits/c0')) return json({ tree: { sha: 't0' } });
    if (method === 'GET' && path.startsWith('/repos/o/r/git/trees/t0')) return json({ truncated: false, tree: Object.entries(opts.existing ?? {}).map(([p, sha]) => ({ path: p, sha, type: 'blob' })) });
    if (method === 'POST' && path.endsWith('/git/blobs')) {
      if (opts.failContent !== undefined && Buffer.from(body.content, 'base64').toString() === opts.failContent) return json({ message: 'boom' }, 500);
      return json({ sha: `b${++n}` });
    }
    if (method === 'POST' && path.endsWith('/git/trees')) return json({ sha: 't1' });
    if (method === 'POST' && path.endsWith('/git/commits')) return json({ sha: 'c1' });
    if (method === 'PATCH' && path.endsWith('/git/refs/heads/main')) return json({});
    return json({ message: `unexpected ${method} ${path}` }, 404);
  }) as typeof fetch;
  return calls;
}
