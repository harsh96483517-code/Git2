import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

// Tokens are encrypted at rest (AES-256-GCM) in memory and on disk, and never leave the server.
const key = crypto.createHash('sha256').update(config.sessionSecret).digest();
const enc = (t: string) => {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([c.update(t, 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), body]).toString('base64');
};
const dec = (s: string) => {
  const b = Buffer.from(s, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', key, b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
};

export interface User { login: string; avatar: string }
interface Rec { tokenEnc: string; user: User; exp: number }
const FILE = process.env.SESSION_FILE ?? path.resolve('data/sessions.json');
const TTL = 8 * 3600 * 1000;
const store = new Map<string, Rec>();

try {
  const raw = JSON.parse(fs.readFileSync(FILE, 'utf8')) as Record<string, Rec>;
  const now = Date.now();
  for (const [k, v] of Object.entries(raw)) if (v && typeof v.tokenEnc === 'string' && v.exp > now) store.set(k, v);
} catch { /* no saved sessions yet */ }

let timer: NodeJS.Timeout | undefined;
const write = () => {
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true, mode: 0o700 });
    const tmp = `${FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(store)), { mode: 0o600 });
    fs.renameSync(tmp, FILE);
  } catch (e) { console.error('Could not save sessions:', (e as Error).message); }
};
const persist = () => { clearTimeout(timer); timer = setTimeout(write, 500); };
export const flushSessions = () => { clearTimeout(timer); write(); };

export const createSession = (token: string, user: User) => {
  const sid = crypto.randomBytes(32).toString('hex');
  store.set(sid, { tokenEnc: enc(token), user, exp: Date.now() + TTL });
  persist();
  return sid;
};
export const getSession = (sid?: string) => {
  const s = sid ? store.get(sid) : undefined;
  if (!sid || !s) return null;
  if (s.exp < Date.now()) { store.delete(sid); persist(); return null; }
  try { return { token: dec(s.tokenEnc), user: s.user }; }
  catch { store.delete(sid); persist(); return null; } // saved with a different SESSION_SECRET
};
export const destroySession = (sid?: string) => { if (sid && store.delete(sid)) persist(); };
