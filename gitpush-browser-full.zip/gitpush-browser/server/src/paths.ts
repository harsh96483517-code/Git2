export class ZipError extends Error {}
export interface ExtractedFile { path: string; data: Buffer }

/** Returns a clean relative path, or throws on traversal / absolute / drive-letter paths (ZIP Slip). */
export function safePath(raw: string): string {
  const p = raw.replace(/\\/g, '/');
  if (p.includes('\0') || p.startsWith('/') || /^[a-zA-Z]:/.test(p)) throw new ZipError(`Unsafe path in ZIP: ${raw}`);
  const parts = p.split('/').filter((s) => s !== '' && s !== '.');
  if (parts.includes('..')) throw new ZipError(`Path traversal in ZIP: ${raw}`);
  return parts.join('/');
}
