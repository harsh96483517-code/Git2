import { Component, StrictMode, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { applyTheme, getTheme } from './theme';
import './index.css';

class Boundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center p-6">
        <div className="glass rounded-[32px] p-7">
          <h1 className="text-2xl font-bold">Something went wrong</h1>
          <p className="muted mt-2">The page hit an unexpected error. Reload to continue. Your GitHub session is not affected.</p>
          <button className="btn btn-accent mt-5" onClick={() => location.reload()}>Reload</button>
        </div>
      </div>
    );
  }
}

applyTheme(getTheme());
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (getTheme() === 'system') applyTheme('system'); });
createRoot(document.getElementById('root')!).render(<StrictMode><Boundary><App /></Boundary></StrictMode>);
