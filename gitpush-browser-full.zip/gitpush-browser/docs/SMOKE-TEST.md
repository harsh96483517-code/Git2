# End-to-end smoke test

Use a throwaway GitHub repository. You need a GitHub OAuth App (callback `http://localhost:8787/auth/callback`).
Test ZIP: a few text files, one nested folder, one small PNG, and one file you will later change.

| # | Do this | Expect |
|---|---------|--------|
| 1 | Start server (`npm run dev`) and web (`npm run dev`), open http://localhost:5173 | Welcome screen with "Connect GitHub" |
| 2 | Click Connect GitHub, cancel on GitHub | Back on Welcome with "sign-in was cancelled" |
| 3 | Connect again and approve | Home shows your username; Settings shows your avatar |
| 4 | Repositories | Your repos load; archived or read-only ones are greyed out |
| 5 | New repository (private) | It appears, is selected, and a branch appears within a few seconds |
| 6 | New branch `test/gitpush` | Branch is selected in the dropdown |
| 7 | Upload: choose the test ZIP, press Extract | File count and size shown, folder tree matches the ZIP |
| 8 | Rename a file, create a folder, delete one file, preview the PNG and a text file | Tree and Files screen reflect each change |
| 9 | Upload a non-ZIP renamed to `.zip` | Clear "Invalid or corrupted ZIP" error |
| 10 | Upload to GitHub with the default message | Progress bar, then a commit link; the commit on GitHub has exactly the files you kept |
| 11 | Repeat step 10 unchanged | Succeeds or says nothing new; no conflict (identical content) |
| 12 | Change one file in the ZIP, extract again, upload with "Stop and show me" | Conflict list names that one file and nothing is uploaded |
| 13 | Choose Overwrite existing | New commit changes only that file |
| 14 | Start an upload of many files and press Cancel upload | "Upload cancelled", no new commit on GitHub |
| 15 | Settings, Sign out | Back on Welcome; the app no longer appears as authorised under GitHub Settings, Applications (token revoked) |
| 16 | Restart the server while signed in, reload the page | Still signed in (sessions are saved to `server/data/`) |

Report any step that does not match, with the browser console and server log output.
