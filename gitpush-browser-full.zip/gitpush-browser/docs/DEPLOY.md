# Deploying GitPush Browser

GitPush runs as one container (or one Node process) that serves both the API and the built web app. It needs HTTPS: the session cookie is `Secure` and the server refuses to start in production with a non-https `APP_BASE_URL`.

## 1. GitHub OAuth App
Create a separate OAuth App for production. Homepage: `https://YOUR_DOMAIN`. Callback: `https://YOUR_DOMAIN/auth/callback`.

## 2. Configure
```
cp .env.production.example .env     # fill in client id/secret and a SESSION_SECRET
```
| Variable | Meaning |
|---|---|
| `APP_BASE_URL` | Public https URL of the app |
| `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` | From the OAuth App. The secret exists only on the server |
| `SESSION_SECRET` | 32+ chars. Encrypts saved tokens. Changing it signs everyone out |
| `TRUST_PROXY` | `1` behind one reverse proxy, otherwise `0` |
| `SESSION_FILE` | Where sessions are saved (the image uses `/data/sessions.json`, a volume) |
| `WEB_DIST` | Folder of the built web app (the image sets it) |

## 3. Run with Docker
```
docker compose up -d --build
curl http://127.0.0.1:8787/health      # {"ok":true}
```
Put an HTTPS reverse proxy in front. With Caddy that is two lines:
```
gitpush.example.com {
  reverse_proxy 127.0.0.1:8787
}
```

## 4. Run without Docker
```
cd web && npm install && npm run build
cd ../server && npm install && npm run build
NODE_ENV=production WEB_DIST=../web/dist node --env-file=.env dist/index.js
```

## Operating notes
- **One instance only.** Sessions are a local file and extracted ZIPs and upload jobs live in memory, so do not run several copies behind a load balancer.
- **Memory:** budget 2 GB. Each session may hold 3 extracted ZIPs and the server caps the total at 1 GB. Restarting the server discards extracted files and running uploads (people stay signed in).
- **Logs** contain error messages only, never tokens or file contents.
- **Updating:** `git pull && docker compose up -d --build`.
- **Lockfiles:** run `npm install` once in `web/` and `server/` and commit the `package-lock.json` files so builds are repeatable.
- **Revoking access:** users can sign out in the app (revokes the token) or remove the app under GitHub Settings, Applications.
