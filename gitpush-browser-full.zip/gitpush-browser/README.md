# GitPush Browser

ZIP -> extract -> browse -> push to GitHub in one commit.

## Architecture
- `server/` Node + Express + TypeScript. Holds the GitHub OAuth secret and tokens. The browser only gets an httpOnly session cookie, never a token.
- `web/` React + TS + Tailwind + Vite. Dev server proxies `/api` and `/auth` to the server.
- Upload path: ZIP (multer, memory) -> `zip.ts` safe extract -> `github.ts` blobs -> tree -> commit -> fast-forward ref.

## Phase status
| # | Phase | Status |
|---|-------|--------|
| 1 | Architecture | scaffolded, NOT yet run (no npm access in the build sandbox) |
| 2 | Premium UI | shell, welcome, home, upload picker, repo list, settings written, untested; other screens come with their features |
| 3 | ZIP extraction | yauzl extractor, `/api/zip/extract`, tree view in Upload screen written, untested |
| 4 | File manager | server file operations tested; UI untested |
| 5 | GitHub OAuth | hardened: error redirects, session expiry UI, token revocation on sign-out, login limiter; written, untested |
| 6 | Repo/branch selection | repo list (300 max), create repo, branch list, create branch, folder picker, recents; written, untested |
| 7 | Upload/commit engine | `/api/push` jobs, progress polling, cancel, conflict choices, retry, commit link; engine logic tested against a fake GitHub, routes and UI untested |
| 8 | Security and error handling | done; covered by unit tests |
| 9 | Test the workflow | 28 automated server tests pass; real OAuth, GitHub and browser run still needs you (docs/SMOKE-TEST.md); CI workflow added |
| 10 | Production deployment | Dockerfile, compose file, https-only production check, CSP, static serving, `docs/DEPLOY.md`; never built or run |

## Run
1. Create a GitHub OAuth App; callback `http://localhost:8787/auth/callback`.
2. `cd server && cp .env.example .env` and fill it in.
3. `npm install && npm run dev`, then open `/health`.
4. In another terminal: `cd web && npm install && npm run dev`, open http://localhost:5173.

## GitHub OAuth notes
- Scopes requested: `repo` (push to public and private repos) and `workflow` (needed to push files under `.github/workflows`). Remove `workflow` in `server/src/index.ts` if you never push workflow files.
- Sign-out revokes only this app's token at GitHub (the user does not have to re-authorize the whole app next time).
- A fresh session id is issued on every login. Failed or cancelled sign-ins return to the app with a readable message.
- Set `TRUST_PROXY=1` only behind a single reverse proxy; otherwise the per-IP limiter sees the proxy's address.

## Deploying
See `docs/DEPLOY.md` (Docker or plain Node, behind an HTTPS reverse proxy).

## Checking it yourself
- `docs/SMOKE-TEST.md` is a 16-step manual run-through against a throwaway repo.
- `.github/workflows/build.yml` runs install, type-check, tests, both builds and the Docker build on every push, and uploads a deployable zip (Actions run page, Artifacts). The type-check and web build have never been run, so expect to fix a few errors on the first CI run.

## Upload behaviour
- One commit per upload, built with the Git Data API (blobs, tree, commit, fast-forward ref update). If any file fails, no commit is made and the branch is untouched.
- Files already in the repo with identical content are left alone; different content is a conflict you resolve (stop, skip, or overwrite).
- Retry reuses blobs already uploaded to the same repo. Cancel works until the final commit step begins.
- If the branch moves on GitHub during an upload the ref update is rejected (never forced) and nothing changes.
- Large files go through the JSON blob API as base64, so files near 100 MB may fail; GitHub recommends staying under 50 MB.
- Upload history is not stored yet (jobs are kept in memory for one hour).

## Tests
`cd server && npm test` (Node 20+, uses `tsx`). 28 tests cover: ZIP path safety, branch and repo name validation, file-manager operations, in-memory extraction storage, the upload job layer, and the whole commit engine, using an in-memory fake of the GitHub Git Data API (fresh push, destination folder, conflicts, skip/overwrite, unchanged files, failed blobs, retry cache, cancel, readable GitHub errors, no secrets in job output). They passed in the build sandbox using Node's own TypeScript support. Not covered: the Express routes and session file, OAuth against real GitHub, yauzl extraction of real ZIPs, and the React UI.

## Security notes
- No CORS is enabled (same-origin only); state-changing requests need an `X-Requested-With` header; API and auth responses are `no-store`.
- Per-IP limits: 20 sign-in requests, 10 ZIP uploads, 600 API requests per minute.
- Repo names made only of dots are rejected (they could rewrite the GitHub API URL path); found by the tests.
- Run behind HTTPS in production so the session cookie is `Secure`.

## Known limits (to fix in later phases)
- OAuth uses the classic web flow with a `state` check; PKCE is not added yet.
- Sessions are saved to an encrypted JSON file (`data/sessions.json`, single server instance only). Extractions and upload jobs are still memory-only.
- Extracted files are held in server memory (3 per session, 1 GB total, 1 hour). Move to disk if you need more.
- Encrypted ZIPs are rejected, not prompted for a password.
- Very large trees and folders (thousands of files) render slowly in the UI; virtualize later.
- File manager edits the server-side copy only; no multi-select or move-between-folders UI yet (rename to a new path moves a file).
- Existing empty repos (no commits) are not supported by the commit engine; repos created in the app start with a README.
- Repo and branch lists are capped at 300 items; the folder suggestions at 500.
